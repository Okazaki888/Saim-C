/* ============================================================
   กระบอกเซียมซี — App Logic
   ESP32 /api/status polling + Demo Mode simulation
   ============================================================ */

'use strict';

const RECORD_SECS = 10; // ← เปลี่ยนตรงนี้เพื่อปรับเวลา

// ── State ─────────────────────────────────────────────────────
const STATE = {
  esp32Ip: '',
  polling: null,
  demoInterval: null,
  demoMode: false,
  connected: false,
  history: [],

  _demoPhase: 'wait',
  _demoTimer: 0,
  _demoGx: 0,
  _demoGy: 0,
  _demoShaking: false,
  _demoProgress: 0,
  _demoLottery: '',
  _demoLotteryTime: '',
  _demoShakeCount: 0,
};

// ── DOM refs ──────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const el = {
  connectionDot: $('connectionDot'),
  connectionLabel: $('connectionLabel'),
  espIp: $('espIp'),
  btnConnect: $('btnConnect'),
  btnDemo: $('btnDemo'),
  shakeCard: $('shakeCard'),
  shakeIcon: $('shakeIcon'),
  shakeStatus: $('shakeStatus'),
  shakeSub: $('shakeSub'),
  gyroX: $('gyroX'),
  gyroY: $('gyroY'),
  barX: $('barX'),
  barY: $('barY'),
  progressFill: $('progressFill'),
  progressPct: $('progressPct'),
  progressTime: $('progressTime'),
  stateBadge: $('stateBadge'),
  lotteryNumber: $('lotteryNumber'),
  lotteryTime: $('lotteryTime'),
  historyList: $('historyList'),
  stateWait: $('stateWait'),
  stateRec: $('stateRec'),
  stateComp: $('stateComp'),
  stateCool: $('stateCool'),
};

// ── Boot ──────────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
  spawnParticles();
  resetDigits();
  setConnectionStatus('idle', 'ยังไม่ได้เชื่อมต่อ');

  const saved = localStorage.getItem('siamsi_ip');
  if (saved) el.espIp.value = saved;

  el.espIp.addEventListener('keydown', e => { if (e.key === 'Enter') connectToESP(); });
});

// ── Connect to real ESP32 ─────────────────────────────────────
function connectToESP() {
  const ip = el.espIp.value.trim();
  if (!ip) { flashInput(); return; }

  if (STATE.demoMode) stopDemo(false);

  STATE.esp32Ip = ip;
  localStorage.setItem('siamsi_ip', ip);

  setConnectionStatus('idle', 'กำลังเชื่อมต่อ...');
  el.btnConnect.disabled = true;
  el.btnConnect.textContent = '⏳';

  if (STATE.polling) clearInterval(STATE.polling);

  fetchStatus().then(() => {
    el.btnConnect.disabled = false;
    el.btnConnect.textContent = 'เชื่อมต่อ';
    STATE.polling = setInterval(fetchStatus, 900);
  }).catch(() => {
    el.btnConnect.disabled = false;
    el.btnConnect.textContent = 'เชื่อมต่อ';
  });
}

async function fetchStatus() {
  const url = `http://${STATE.esp32Ip}/api/status`;
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(2500) });
    const data = await res.json();
    STATE.connected = true;
    updateUI(data);
  } catch (err) {
    STATE.connected = false;
    setConnectionStatus('error', 'เชื่อมต่อไม่ได้ — ตรวจสอบ IP');
    throw err;
  }
}

// ── Demo Mode ─────────────────────────────────────────────────
function toggleDemo() {
  if (STATE.demoMode) {
    stopDemo(true);
  } else {
    startDemo();
  }
}

function startDemo() {
  if (STATE.polling) { clearInterval(STATE.polling); STATE.polling = null; }
  STATE.demoMode = true;
  STATE.connected = true;
  STATE._demoPhase = 'wait';
  STATE._demoTimer = 0;
  STATE._demoProgress = 0;
  STATE._demoShaking = false;
  STATE._demoShakeCount = 0;
  STATE._demoLottery = '';
  STATE._demoLotteryTime = '';

  el.btnDemo.textContent = '⏹ หยุด Demo';
  el.btnDemo.classList.add('active');
  setConnectionStatus('demo', 'Demo Mode');

  STATE.demoInterval = setInterval(demoTick, 200);
}

function stopDemo(resetUI) {
  STATE.demoMode = false;
  clearInterval(STATE.demoInterval);
  STATE.demoInterval = null;
  el.btnDemo.textContent = '▶ ทดลอง Demo Mode';
  el.btnDemo.classList.remove('active');
  if (resetUI) {
    setConnectionStatus('idle', 'ยังไม่ได้เชื่อมต่อ');
    resetDigits();
    setShaking(false);
    updateProgress(0);
    updateStateBadge('wait');
    activateStateNode('wait');
  }
}

let _demoTick = 0;
function demoTick() {
  _demoTick++;
  const phase = STATE._demoPhase;
  // TOTAL_TICKS = RECORD_SECS วินาที × 5 ticks/วินาที (200ms/tick)
  const TOTAL_TICKS = RECORD_SECS * 5;

  if (phase === 'wait') {
    const t = _demoTick * 200 / 1000;
    STATE._demoGx = randFloat(-15, 15) * Math.sin(_demoTick * 0.4);
    STATE._demoGy = randFloat(-15, 15) * Math.cos(_demoTick * 0.3);
    STATE._demoShaking = false;

    if (t > 3) {
      STATE._demoGx = randFloat(60, 150) * (Math.random() > 0.5 ? 1 : -1);
      STATE._demoGy = randFloat(60, 150) * (Math.random() > 0.5 ? 1 : -1);
      STATE._demoShaking = true;
      STATE._demoShakeCount++;

      if (STATE._demoShakeCount >= 5) {
        STATE._demoPhase = 'recording';
        STATE._demoTimer = 0;
        STATE._demoShakeCount = 0;
        _demoTick = 0;
      }
    }
    updateUI(makeDemoPayload());
    return;
  }

  // ── RECORDING phase: count up 25 ticks = 5s for demo ──
  if (phase === 'recording') {
    const TOTAL_TICKS = 25;
    STATE._demoTimer++;
    STATE._demoProgress = Math.min(STATE._demoTimer / TOTAL_TICKS, 1.0);
    STATE._demoGx = randFloat(40, 130) * (Math.random() > 0.5 ? 1 : -1);
    STATE._demoGy = randFloat(40, 130) * (Math.random() > 0.5 ? 1 : -1);
    STATE._demoShaking = true;

    if (STATE._demoTimer >= TOTAL_TICKS) {
      STATE._demoPhase = 'computing';
      STATE._demoProgress = 1.0;
      _demoTick = 0;
    }
    updateUI(makeDemoPayload());
    return;
  }

  if (phase === 'computing') {
    STATE._demoLottery = generateFakeLottery();
    STATE._demoLotteryTime = nowThai();
    STATE._demoGx = 0; STATE._demoGy = 0;
    STATE._demoShaking = false;
    STATE._demoPhase = 'cooldown';
    _demoTick = 0;

    STATE.history.unshift({ number: STATE._demoLottery, datetime: STATE._demoLotteryTime });
    if (STATE.history.length > 10) STATE.history.pop();

    updateUI(makeDemoPayload());
    return;
  }

  if (phase === 'cooldown') {
    STATE._demoGx = randFloat(-5, 5);
    STATE._demoGy = randFloat(-5, 5);
    STATE._demoShaking = false;

    if (_demoTick >= 15) {
      STATE._demoPhase = 'wait';
      STATE._demoProgress = 0;
      STATE._demoTimer = 0;
      _demoTick = 0;
    }
    updateUI(makeDemoPayload());
  }
}

function makeDemoPayload() {
  const ph = STATE._demoPhase;
  const statusMap = {
    wait: 'รอการเขย่า',
    recording: 'กำลังบันทึก...',
    computing: 'กำลังคำนวณ...',
    cooldown: 'แสดงผลเลข',
  };
  return {
    gx: STATE._demoGx.toFixed(2),
    gy: STATE._demoGy.toFixed(2),
    shaking: STATE._demoShaking,
    status: statusMap[ph],
    lottery: STATE._demoLottery,
    lottery_time: STATE._demoLotteryTime,
    recording: ph === 'recording',
    progress: STATE._demoProgress,
    history: STATE.history,
    _phase: ph,
  };
}

// ── UI Update ─────────────────────────────────────────────────
function updateUI(data) {
  if (STATE.demoMode) {
    setConnectionStatus('demo', 'Demo Mode');
  } else {
    setConnectionStatus(data.shaking ? 'shaking' : 'connected',
      data.shaking ? 'ตรวจพบการเขย่า!' : 'เชื่อมต่อแล้ว');
  }

  setShaking(data.shaking);
  el.shakeStatus.textContent = data.status;
  el.shakeSub.textContent = data.shaking
    ? '🔥 ตรวจพบการเขย่า!'
    : data.recording
      ? `⏺️ กำลังบันทึก — เขย่าต่อไป!`
      : 'ถือกระบอกแล้วเขย่าแรงๆ';

  const gx = parseFloat(data.gx) || 0;
  const gy = parseFloat(data.gy) || 0;
  updateGyroBar(el.barX, el.gyroX, gx);
  updateGyroBar(el.barY, el.gyroY, gy);

  updateProgress(data.progress || 0);

  const phase = data._phase || inferPhase(data);
  updateStateBadge(phase);
  activateStateNode(phase);

  // Progress time label
  if (data.recording || phase === 'recording') {
    const elapsed = Math.round((data.progress || 0) * 50); // 0–5 วินาที
    el.progressTime.textContent = `${elapsed} / 5 วินาที`;
  } else if (phase === 'cooldown') {
    el.progressTime.textContent = 'บันทึกเสร็จสิ้น ✓';
  } else {
    el.progressTime.textContent = '0 / 5 วินาที';
  }

  if (data.lottery && data.lottery !== '') {
    setLottery(data.lottery, data.lottery_time || '');
  } else {
    if (!STATE._prevLottery) resetDigits();
  }

  if (data.history && data.history.length > 0) {
    renderHistory(data.history);
  }

  STATE._prevLottery = data.lottery;
}

// ── Gyro bar ──────────────────────────────────────────────────
function updateGyroBar(barEl, valEl, value) {
  const MAX = 180;
  const absVal = Math.abs(value);
  const pct = Math.min(absVal / MAX, 1) * 50;
  const high = absVal > 80;

  barEl.style.width = `${pct * 2}%`;
  barEl.style.left = value >= 0 ? '50%' : `${50 - pct * 2}%`;
  barEl.classList.toggle('high', high);
  valEl.textContent = `${value >= 0 ? '+' : ''}${parseFloat(value).toFixed(1)} °/s`;
  valEl.classList.toggle('high', high);
}

// ── Progress ──────────────────────────────────────────────────
function updateProgress(ratio) {
  const pct = Math.round(ratio * 100);
  el.progressFill.style.width = `${pct}%`;
  el.progressPct.textContent = `${pct}%`;
  el.progressFill.classList.toggle('complete', ratio >= 1.0);
}

// ── State badge ───────────────────────────────────────────────
function updateStateBadge(phase) {
  const labels = { wait: 'WAIT', recording: 'RECORDING', computing: 'COMPUTING', cooldown: 'COOLDOWN' };
  el.stateBadge.textContent = labels[phase] || 'WAIT';
  el.stateBadge.className = `state-badge ${phase}`;
}

function activateStateNode(phase) {
  const map = { wait: el.stateWait, recording: el.stateRec, computing: el.stateComp, cooldown: el.stateCool };
  [el.stateWait, el.stateRec, el.stateComp, el.stateCool].forEach(n => n.classList.remove('active'));
  if (map[phase]) map[phase].classList.add('active');
}

function setShaking(isShaking) {
  el.shakeCard.classList.toggle('shaking', isShaking);
}

// ── Lottery digits ────────────────────────────────────────────
let _lastLottery = '';
function setLottery(number, time) {
  if (number === _lastLottery) return;
  _lastLottery = number;

  const digits = el.lotteryNumber.querySelectorAll('.digit');
  const nums = number.split('');
  const positions = [0, 1, 2, 3, 4, 5];

  positions.forEach((pos, i) => {
    const ch = nums[i] || '-';
    setTimeout(() => {
      const d = digits[pos];
      d.textContent = ch;
      d.classList.remove('empty', 'reveal');
      void d.offsetWidth;
      d.classList.add('reveal');
    }, i * 120);
  });

  el.lotteryTime.textContent = time ? `🕐 ออกเมื่อ: ${time}` : '';
}

function resetDigits() {
  _lastLottery = '';
  el.lotteryNumber.querySelectorAll('.digit').forEach(d => {
    d.textContent = '-';
    d.classList.add('empty');
    d.classList.remove('reveal');
  });
  el.lotteryTime.textContent = 'ยังไม่มีผล';
}

// ── History ───────────────────────────────────────────────────
let _lastHistoryKey = '';
function renderHistory(items) {
  if (!items || items.length === 0) return;

  const key = items.map(it => it.number + '|' + it.datetime).join('~');
  if (key === _lastHistoryKey) return;

  const existingNums = new Set(
    Array.from(el.historyList.querySelectorAll('.history-number'))
      .map(n => n.textContent)
  );

  _lastHistoryKey = key;
  el.historyList.innerHTML = '';

  items.forEach((item, i) => {
    const formatted = fmtNumber(item.number);
    const isNew = !existingNums.has(formatted);

    const row = document.createElement('div');
    row.className = 'history-item';
    if (!isNew) row.style.animation = 'none';

    row.innerHTML = `
      <span class="history-rank">${i === 0 ? '🥇' : i + 1}</span>
      <span class="history-number">${formatted}</span>
      ${i === 0 ? '<span class="history-new-badge">ล่าสุด</span>' : ''}
      <span class="history-datetime">${item.datetime}</span>
    `;
    el.historyList.appendChild(row);
  });
}

// ── Helpers ───────────────────────────────────────────────────
function inferPhase(data) {
  if (data.recording) return 'recording';
  if (data.status?.includes('คำนวณ')) return 'computing';
  if (data.lottery && data.progress >= 1) return 'cooldown';
  return 'wait';
}

function setConnectionStatus(type, label) {
  el.connectionDot.className = `dot ${type}`;
  el.connectionLabel.textContent = label;
}

function fmtNumber(n) {
  if (!n || n.length !== 6) return n;
  return `${n.slice(0, 3)}-${n.slice(3, 6)}`;
}

function generateFakeLottery() {
  return Array.from({ length: 6 }, () => Math.floor(Math.random() * 10)).join('');
}

function nowThai() {
  const d = new Date();
  const day = d.getDate().toString().padStart(2, '0');
  const month = (d.getMonth() + 1).toString().padStart(2, '0');
  const year = d.getFullYear();
  const hh = d.getHours().toString().padStart(2, '0');
  const mm = d.getMinutes().toString().padStart(2, '0');
  const ss = d.getSeconds().toString().padStart(2, '0');
  return `${day}/${month}/${year} ${hh}:${mm}:${ss}`;
}

function randFloat(min, max) {
  return Math.random() * (max - min) + min;
}

function flashInput() {
  el.espIp.style.borderColor = 'var(--red)';
  el.espIp.style.boxShadow = '0 0 0 3px rgba(230,57,70,0.25)';
  setTimeout(() => {
    el.espIp.style.borderColor = '';
    el.espIp.style.boxShadow = '';
  }, 700);
}

// ── Particles ─────────────────────────────────────────────────
function spawnParticles() {
  const container = $('particles');
  const COLORS = ['#f5c842', '#ff9f1c', '#4cc9f0', '#7b2fff', '#2dc653', '#ffe98a'];
  const COUNT = 30;

  for (let i = 0; i < COUNT; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    const size = randFloat(2, 6);
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];
    const left = randFloat(0, 100);
    const dur = randFloat(12, 30);
    const delay = randFloat(0, 20);
    p.style.cssText = `
      width:${size}px;height:${size}px;background:${color};
      left:${left}%;bottom:-10px;
      animation-duration:${dur}s;animation-delay:${delay}s;
      opacity:0;box-shadow:0 0 ${size * 2}px ${color};
    `;
    container.appendChild(p);
  }
}

window.connectToESP = connectToESP;
window.toggleDemo = toggleDemo;