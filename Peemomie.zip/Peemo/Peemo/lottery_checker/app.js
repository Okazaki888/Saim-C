/* ============================================================
   ดูดวงเซียมซี — Fortune Engine
   เลข 6 หลัก → คะแนนโชค 6 ด้าน → คำทำนาย
   ============================================================ */

'use strict';

// ── Deterministic PRNG (Mulberry32) ──────────────────────────
// ทำให้เลขเดิม → ผลเดิมเสมอ
function mulberry32(seed) {
  return function () {
    seed |= 0; seed = seed + 0x6D2B79F5 | 0;
    let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

function numberToSeed(numStr) {
  // ใช้ FNV-like hash บน digit string → integer seed
  let h = 2166136261;
  for (let i = 0; i < numStr.length; i++) {
    h ^= numStr.charCodeAt(i);
    h = Math.imul(h, 16777619);
    h >>>= 0;
  }
  return h;
}

// ── Fortune Data ──────────────────────────────────────────────
const CATEGORIES = [
  {
    key: 'money',
    icon: '💰',
    name: 'การเงิน-โชคลาภ',
    cls: 'cat-money',
    low:  ['ระวังรายจ่ายที่ไม่จำเป็น ควรประหยัดไว้ก่อน', 'เดือนนี้ไม่เหมาะกับการลงทุนใหญ่', 'การเงินตึงเครียดเล็กน้อย ให้วางแผนรายรับ-รายจ่ายให้ดี'],
    mid:  ['การเงินพอไปได้ รายได้มีแต่ต้องระวังค่าใช้จ่ายฟุ่มเฟือย', 'อาจมีรายได้เล็กๆ น้อยๆ เข้ามา ให้ออมไว้ดีกว่าใช้จ่าย', 'ดวงการเงินกลางๆ ไม่รวยไม่จนในช่วงนี้'],
    high: ['ดวงการเงินดีมาก! มีโอกาสรับเงินก้อน', 'โชคลาภส่อแสงมา อาจได้รับสิ่งที่ไม่คาดคิด', 'เงินทองไหลมาเทมา ระวังอย่าใช้จ่ายเกินตัว'],
  },
  {
    key: 'love',
    icon: '❤️',
    name: 'ความรัก-คนคู่',
    cls: 'cat-love',
    low:  ['ช่วงนี้ยังไม่ใช่เวลาของความรัก ให้โฟกัสที่ตัวเองก่อน', 'ความสัมพันธ์อาจมีปัญหาเล็กน้อย ต้องสื่อสารให้มากขึ้น', 'โสดยังไม่ต้องรีบ เวลาของคุณจะมาเอง'],
    mid:  ['ความรักเดินหน้าไปได้ ต้องใจเย็นและเข้าใจกัน', 'มีคนแอบสนใจคุณอยู่ ลองสังเกตดูรอบๆ', 'ความรักมั่นคงในระดับหนึ่ง ดูแลกันและกันไว้ให้ดี'],
    high: ['ดาวรักส่องสว่าง! มีความรักใหม่หรือความสัมพันธ์ที่หวาน', 'คนรักใจดีมากต่อคุณในช่วงนี้ ทำดีตอบแทนด้วย', 'ดวงรักพุ่ง! อาจมีข่าวดีเรื่องความรักเร็วๆ นี้'],
  },
  {
    key: 'career',
    icon: '💼',
    name: 'การงาน-ความสำเร็จ',
    cls: 'cat-career',
    low:  ['การงานอาจมีอุปสรรคเล็กน้อย อดทนและพยายามต่อไป', 'ยังไม่ใช่เวลาเหมาะสมสำหรับการเปลี่ยนงาน', 'โปรเจกต์อาจล่าช้า ต้องติดตามงานให้ใกล้ชิด'],
    mid:  ['การงานดำเนินไปได้ตามปกติ อาจมีงานใหม่เข้ามา', 'ทำงานหนักสักนิด แล้วผลตอบแทนจะตามมา', 'เจ้านายเริ่มสังเกตเห็นความสามารถของคุณ'],
    high: ['การงานพุ่งสุดๆ! โอกาสเลื่อนขั้นหรืองานใหม่กำลังมา', 'ความสำเร็จอยู่ตรงหน้าแล้ว รีบคว้าไว้เลย!', 'ไอเดียของคุณจะได้รับการยอมรับในช่วงนี้'],
  },
  {
    key: 'health',
    icon: '🏥',
    name: 'สุขภาพ-พลังงาน',
    cls: 'cat-health',
    low:  ['ระวังสุขภาพด้วย อย่าปล่อยให้ร่างกายอ่อนแอ', 'พักผ่อนให้เพียงพอ อย่าทำงานหนักเกินไป', 'ระวังอาการเครียดสะสม ออกกำลังกายสม่ำเสมอ'],
    mid:  ['สุขภาพโดยรวมปกติ แต่ควรระวังในช่วงอากาศเปลี่ยน', 'ดูแลตัวเองให้ดี กินอาหารมีประโยชน์', 'ร่างกายแข็งแรงพอสมควร รักษาไว้ให้ดี'],
    high: ['สุขภาพแข็งแกร่ง เต็มไปด้วยพลังงาน!', 'ร่างกายและจิตใจสมดุลมากในช่วงนี้', 'พลังงานล้นเหลือ เหมาะกับการเริ่มโปรเจกต์ใหม่!'],
  },
  {
    key: 'social',
    icon: '🤝',
    name: 'สังคม-มิตรภาพ',
    cls: 'cat-social',
    low:  ['ช่วงนี้ขอบเขตส่วนตัวสำคัญมาก ระวังคนที่ไม่จริงใจ', 'เพื่อนฝูงอาจห่างหายบ้าง แต่ไม่เป็นไร', 'ระวังความเข้าใจผิดกับคนรอบข้าง'],
    mid:  ['สังคมไปได้ดี มีเพื่อนคอยช่วยเหลือ', 'การพบปะสังสรรค์ให้ผลดีในช่วงนี้', 'คนรอบข้างให้ความร่วมมือดี'],
    high: ['บุคลิกดึงดูดมากในช่วงนี้ ไปไหนมีแต่คนชอบ!', 'เครือข่ายสังคมขยายตัวอย่างรวดเร็ว', 'คนดีๆ จะเข้ามาในชีวิตคุณในช่วงนี้'],
  },
  {
    key: 'spirit',
    icon: '🧘',
    name: 'จิตใจ-สติปัญญา',
    cls: 'cat-spirit',
    low:  ['จิตใจอ่อนแอเล็กน้อย ลองทำสมาธิหรือพักผ่อน', 'ช่วงนี้ตัดสินใจยาก ขอคำปรึกษาจากคนที่ไว้ใจได้', 'อย่าปล่อยให้ความวิตกกังวลท่วมท้น'],
    mid:  ['จิตใจสงบพอสมควร ความคิดชัดเจน', 'สติปัญญาคมขึ้น เหมาะกับการเรียนรู้สิ่งใหม่', 'จิตใจมั่นคง สามารถรับมือกับปัญหาได้ดี'],
    high: ['จิตใจเฉียบคมมากในช่วงนี้ ไอเดียพุ่งพล่าน!', 'สัญชาตญาณแม่นยำ เชื่อความรู้สึกตัวเองไว้ได้', 'จิตใจสงบและสว่าง เป็นช่วงเวลาดีสำหรับการตัดสินใจ'],
  },
];

// ── Luck Level Config ─────────────────────────────────────────
const LUCK_LEVELS = [
  { min: 0,  max: 30, label: 'ดวงตก 😔',        cls: 'level-poor',   stars: '⭐',           msg: 'ช่วงนี้ดวงค่อนข้างตก ควรระมัดระวังและวางแผนรอบคอบ อย่าเสี่ยงในสิ่งที่ไม่จำเป็น' },
  { min: 30, max: 50, label: 'ดวงธรรมดา 🌤️',  cls: 'level-low',    stars: '⭐⭐',         msg: 'ดวงกลางๆ ไม่ดีไม่แย่ ต้องพยายามเองและระวังสิ่งรอบข้าง' },
  { min: 50, max: 65, label: 'ดวงพอใช้ 🌟',    cls: 'level-medium', stars: '⭐⭐⭐',       msg: 'ดวงโอเค มีโอกาสดีบ้างในบางด้าน แต่ต้องขยันและใจเย็น' },
  { min: 65, max: 80, label: 'ดวงดี ✨',        cls: 'level-good',   stars: '⭐⭐⭐⭐',     msg: 'ดวงดีมาก! โอกาสดีๆ กำลังรออยู่ คว้าไว้ให้ดี อย่าปล่อยผ่านไป' },
  { min: 80, max: 92, label: 'ดวงเฮง 🔥',      cls: 'level-great',  stars: '⭐⭐⭐⭐⭐',   msg: 'ดวงเฮงมากๆ! ช่วงนี้ทุกอย่างจะเป็นไปด้วยดี โชคเข้าข้างคุณ' },
  { min: 92, max: 101,'label': 'ดวงปัง! 🎉',   cls: 'level-jackpot',stars: '🌟🌟🌟🌟🌟', msg: 'ดวงปังสุดๆ! นี่คือช่วงเวลาทองของคุณ ทุกด้านพร้อมสำหรับความสำเร็จ อย่าปล่อยโอกาสนี้ผ่านไปเด็ดขาด!' },
];

// ── Grand Fortune Paragraphs ──────────────────────────────────
const FORTUNE_TEXTS = {
  poor: `เลขที่ออกมาชี้ว่าช่วงนี้มีบางอย่างที่ต้องระมัดระวัง
อย่าเพิ่งรีบตัดสินใจเรื่องใหญ่ๆ ให้สังเกตสัญญาณรอบข้างให้ดี
ความอดทนคือกุญแจ — ดวงจะค่อยๆ ดีขึ้นหากไม่ยอมแพ้`,

  low: `ตัวเลขบ่งบอกว่าช่วงนี้อยู่ในช่วงสะสมพลัง
ยังไม่ถึงเวลาระเบิดฝีมือ แต่กำลังสะสมไว้
วางแผนให้ดี แล้วโอกาสจะมาเอง`,

  medium: `เลขที่ออกมาบ่งชี้ถึงช่วงเวลาที่สมดุล
ไม่ได้ดีหรือแย่ แต่มีโอกาสซ่อนอยู่ในทุกทิศทาง
คนที่มีสายตามองข้ามฟ้าจะเห็นมัน — คุณเป็นคนนั้นไหม?`,

  good: `เลขนี้พาโชคดีมาด้วย!
ดวงดาวจัดเรียงในทิศทางที่เป็นมงคล หลายด้านในชีวิตกำลังจะเบิกบาน
คว้าโอกาสที่เข้ามา แต่อย่าลืมขอบคุณสิ่งดีๆ ที่มีอยู่`,

  great: `ว้าว! เลขที่ออกมาคือสัญลักษณ์แห่งโชคและพลัง
ช่วงนี้สิ่งที่คุณปรารถนามีโอกาสเป็นจริงสูงมาก
เชื่อในตัวเอง ลงมือทำ แล้วจักรวาลจะหนุนนำคุณ`,

  jackpot: `🌟 นี่คือเลขมหามงคล! 🌟
ฟ้าดินเป็นใจ ดาวฤกษ์จัดเรียงตรงกับชะตาของคุณพอดี
ช่วงเวลานี้หายากมาก — ทุกความฝันที่คุณมีมีโอกาสเป็นจริงสูงมาก
อย่าปล่อยให้ช่วงเวลาทองนี้ผ่านไปโดยเปล่าประโยชน์!`,
};

// ── DOM ───────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const DIGIT_IDS = ['d0','d1','d2','d3','d4','d5'];

// ── Boot ──────────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
  spawnStars();
  setupDigitInputs();
});

// ── Digit box auto-advance ────────────────────────────────────
function setupDigitInputs() {
  DIGIT_IDS.forEach((id, i) => {
    const el = $(id);
    el.addEventListener('input', e => {
      const val = e.target.value.replace(/\D/g,'');
      e.target.value = val.slice(-1);
      e.target.classList.toggle('filled', val.length > 0);
      if (val.length > 0 && i < 5) $(DIGIT_IDS[i+1]).focus();
    });
    el.addEventListener('keydown', e => {
      if (e.key === 'Backspace' && !el.value && i > 0) $(DIGIT_IDS[i-1]).focus();
      if (e.key === 'Enter') revealFortune();
    });
    el.addEventListener('focus', () => el.select());
  });

  // Quick paste input auto-distribute
  $('quickNum').addEventListener('input', e => {
    const val = e.target.value.replace(/\D/g,'').slice(0,6);
    e.target.value = val;
  });
  $('quickNum').addEventListener('keydown', e => {
    if (e.key === 'Enter') quickFill();
  });
}

function quickFill() {
  const val = $('quickNum').value.replace(/\D/g,'').slice(0,6);
  if (!val) return;
  DIGIT_IDS.forEach((id, i) => {
    const el = $(id);
    el.value = val[i] || '';
    el.classList.toggle('filled', !!val[i]);
  });
  if (val.length === 6) revealFortune();
}

// ── Get number from boxes ─────────────────────────────────────
function getNumber() {
  return DIGIT_IDS.map(id => $(id).value.trim()).join('');
}

// ── Main: Reveal Fortune ──────────────────────────────────────
function revealFortune() {
  const num = getNumber();
  if (num.length < 6 || !/^\d{6}$/.test(num)) {
    flashDigits(); return;
  }

  // Seed PRNG from the number
  const seed  = numberToSeed(num);
  const rand  = mulberry32(seed);

  // Generate scores for each category (weighted toward middle)
  const scores = CATEGORIES.map((cat, i) => {
    // Each digit influences a category + global seed
    const digitInfluence = parseInt(num[i]) / 9; // 0–1
    const r1 = rand();
    const r2 = rand();
    // Blend digit + randomness → score 0–100
    const raw = (digitInfluence * 0.5 + (r1 + r2) / 2 * 0.5) * 100;
    return Math.min(100, Math.max(0, Math.round(raw)));
  });

  const overall = Math.round(scores.reduce((a,b) => a+b, 0) / scores.length);

  // Show fortune section
  $('fortuneSection').style.display = '';
  $('inputSection').style.opacity = '0.4';
  $('inputSection').style.pointerEvents = 'none';

  // Scroll to result
  setTimeout(() => $('fortuneSection').scrollIntoView({ behavior: 'smooth', block: 'start' }), 100);

  // Render overall banner
  renderOverall(num, overall);

  // Render category cards
  renderCategories(scores, rand);

  // Render fortune text
  renderFortuneText(overall);

  // Confetti if jackpot
  if (overall >= 80) setTimeout(() => launchConfetti(overall), 600);
}

// ── Render Overall Banner ─────────────────────────────────────
function renderOverall(num, score) {
  $('overallNumber').textContent = num.slice(0,3) + '–' + num.slice(3,6);

  const level = LUCK_LEVELS.find(l => score >= l.min && score < l.max) || LUCK_LEVELS[0];

  // Animate score bar
  setTimeout(() => {
    $('overallScoreFill').style.width = score + '%';
    $('overallScoreLabel').textContent = score + ' / 100';
  }, 300);

  setTimeout(() => {
    $('overallLevel').textContent = level.label;
    $('overallLevel').className   = 'overall-level ' + level.cls;
    $('overallStars').textContent = level.stars;
    $('overallMsg').textContent   = level.msg;
  }, 200);
}

// ── Render Categories ─────────────────────────────────────────
function renderCategories(scores, rand) {
  const grid = $('categoryGrid');
  grid.innerHTML = '';

  CATEGORIES.forEach((cat, i) => {
    const score = scores[i];
    const tier  = score < 40 ? 'low' : score < 70 ? 'mid' : 'high';
    const msgs  = cat[tier];
    const msg   = msgs[Math.floor(rand() * msgs.length)];
    const stars = scoreToStars(score);

    const card = document.createElement('div');
    card.className = `cat-card ${cat.cls}`;
    card.style.animationDelay = (i * 100) + 'ms';
    card.innerHTML = `
      <div class="cat-header">
        <span class="cat-icon">${cat.icon}</span>
        <span class="cat-name">${cat.name}</span>
        <span class="cat-stars">${stars}</span>
      </div>
      <div class="cat-bar-wrap">
        <div class="cat-bar" id="catBar${i}"></div>
      </div>
      <div class="cat-score">${score} / 100</div>
      <div class="cat-msg">${msg}</div>
    `;
    grid.appendChild(card);

    // Animate bar
    setTimeout(() => {
      $('catBar' + i).style.width = score + '%';
    }, 400 + i * 100);
  });
}

// ── Render Fortune Text ───────────────────────────────────────
function renderFortuneText(score) {
  let key = 'medium';
  if (score < 30) key = 'poor';
  else if (score < 50) key = 'low';
  else if (score < 65) key = 'medium';
  else if (score < 80) key = 'good';
  else if (score < 92) key = 'great';
  else key = 'jackpot';

  $('fortuneScrollText').textContent = FORTUNE_TEXTS[key];
}

// ── Reset ─────────────────────────────────────────────────────
function resetFortune() {
  $('fortuneSection').style.display = 'none';
  $('inputSection').style.opacity = '1';
  $('inputSection').style.pointerEvents = '';
  DIGIT_IDS.forEach(id => {
    $(id).value = '';
    $(id).classList.remove('filled');
  });
  $('quickNum').value = '';
  $('categoryGrid').innerHTML = '';
  $('overallScoreFill').style.width = '0%';
  $('inputSection').scrollIntoView({ behavior: 'smooth' });
}

// ── Helpers ───────────────────────────────────────────────────
function scoreToStars(score) {
  if (score < 20) return '⭐';
  if (score < 40) return '⭐⭐';
  if (score < 60) return '⭐⭐⭐';
  if (score < 80) return '⭐⭐⭐⭐';
  return '⭐⭐⭐⭐⭐';
}

function flashDigits() {
  DIGIT_IDS.forEach(id => {
    const el = $(id);
    el.style.borderColor = 'rgba(230,57,70,0.8)';
    el.style.boxShadow   = '0 0 0 3px rgba(230,57,70,0.2)';
    setTimeout(() => { el.style.borderColor = ''; el.style.boxShadow = ''; }, 700);
  });
}

// ── Confetti ──────────────────────────────────────────────────
function launchConfetti(score) {
  const container = $('confetti');
  const COUNT = score >= 92 ? 120 : 60;
  const COLORS = ['#f5c842','#ff9f1c','#b088ff','#4cc9f0','#ff6b9d','#2dc653','#ffe98a'];

  for (let i = 0; i < COUNT; i++) {
    const p = document.createElement('div');
    p.className = 'confetti-piece';
    const size  = 6 + Math.random() * 8;
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];
    const left  = Math.random() * 100;
    const dur   = 2 + Math.random() * 3;
    const delay = Math.random() * 1.5;
    const isRect = Math.random() > 0.5;

    p.style.cssText = `
      left: ${left}%;
      width: ${isRect ? size * 2 : size}px;
      height: ${size}px;
      background: ${color};
      border-radius: ${isRect ? '2px' : '50%'};
      animation-duration: ${dur}s;
      animation-delay: ${delay}s;
    `;
    container.appendChild(p);
    setTimeout(() => p.remove(), (dur + delay + 0.5) * 1000);
  }
}

// ── Stars background ──────────────────────────────────────────
function spawnStars() {
  const bg = $('starsBg');
  for (let i = 0; i < 80; i++) {
    const s = document.createElement('div');
    s.className = 'star';
    const size = 1 + Math.random() * 2.5;
    s.style.cssText = `
      width: ${size}px; height: ${size}px;
      top:  ${Math.random() * 100}%;
      left: ${Math.random() * 100}%;
      animation-duration: ${2 + Math.random() * 4}s;
      animation-delay: ${Math.random() * 5}s;
    `;
    bg.appendChild(s);
  }
}

// ── Expose globals ────────────────────────────────────────────
window.revealFortune = revealFortune;
window.quickFill     = quickFill;
window.resetFortune  = resetFortune;
