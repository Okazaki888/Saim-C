# กระบอกเซียมซี MPU6050 — ESP32 Web Server Edition

**เวอร์ชัน:** 2.0  
**อุปกรณ์:** ESP32 Dev Module + MPU6050  
**ภาษา:** C++ (Arduino Framework)

---

## สารบัญ

1. [ภาพรวมระบบ](#1-ภาพรวมระบบ)
2. [อุปกรณ์ที่ต้องใช้](#2-อุปกรณ์ที่ต้องใช้)
3. [การเชื่อมต่อสาย](#3-การเชื่อมต่อสาย)
4. [ติดตั้ง Software](#4-ติดตั้ง-software)
5. [ตั้งค่าโค้ดก่อนอัปโหลด](#5-ตั้งค่าโค้ดก่อนอัปโหลด)
6. [อัปโหลดโค้ด](#6-อัปโหลดโค้ด)
7. [การใช้งาน](#7-การใช้งาน)
8. [State Machine](#8-state-machine)
9. [ตาราง API](#9-ตาราง-api)
10. [การปรับแต่งค่า](#10-การปรับแต่งค่า)
11. [การแก้ปัญหา](#11-การแก้ปัญหา)
12. [สิ่งที่แก้ไขจาก v1.0](#12-สิ่งที่แก้ไขจาก-v10)

---

## 1. ภาพรวมระบบ

```
MPU6050  ──I2C──▶  ESP32  ──WiFi──▶  Browser (มือถือ / PC)
(Gyro)            (Web Server)        http://<IP>
```

ESP32 ทำหน้าที่ทุกอย่างในตัวเดียว:

- อ่านค่า Gyroscope X, Y จาก MPU6050 ทุก 100ms
- ตรวจจับการเขย่าผ่าน threshold และ circular buffer
- จับเวลาเขย่า 5 วินาที แล้วคำนวณเลขหวย 6 หลัก
- เสิร์ฟหน้าเว็บแบบ real-time ด้วย polling ทุก 900ms
- ไม่ต้องใช้ Python, Serial, หรือโปรแกรมอื่นเพิ่ม

---

## 2. อุปกรณ์ที่ต้องใช้

| อุปกรณ์ | จำนวน | หมายเหตุ |
|---------|-------|---------|
| ESP32 Dev Module | 1 | รุ่นใดก็ได้ที่มี GPIO 21, 22 |
| MPU6050 Module | 1 | มี Pull-up resistor ในตัว |
| สาย Jumper | 4 | Female-to-Male |
| สาย USB Micro/Type-C | 1 | สำหรับอัปโหลดและไฟ |
| คอมพิวเตอร์ | 1 | ติดตั้ง Arduino IDE |

---

## 3. การเชื่อมต่อสาย

```
MPU6050          ESP32
─────────────────────────
VCC    ────────▶  3.3V   (ห้ามต่อ 5V จะทำ MPU6050 พัง)
GND    ────────▶  GND
SDA    ────────▶  GPIO 21
SCL    ────────▶  GPIO 22
INT    ──ไม่ต่อ──
AD0    ──ไม่ต่อ──  (ค่า default = GND = address 0x68)
```

> **คำเตือน:** MPU6050 ใช้ไฟ 3.3V เท่านั้น การต่อ 5V จะทำให้ IC เสียหายถาวร

---

## 4. ติดตั้ง Software

### 4.1 Arduino IDE

ดาวน์โหลดจาก [https://www.arduino.cc/en/software](https://www.arduino.cc/en/software)

### 4.2 ESP32 Board Package

เปิด Arduino IDE → **File → Preferences**  
ใส่ URL นี้ใน *Additional Boards Manager URLs*:

```
https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
```

จากนั้นไปที่ **Tools → Board → Boards Manager**  
ค้นหา `esp32` แล้วติดตั้ง **"esp32 by Espressif Systems"**

### 4.3 Library ที่ต้องติดตั้ง

ไปที่ **Tools → Manage Libraries** แล้วติดตั้ง:

| ชื่อ Library | ผู้พัฒนา | ค้นหาด้วยคำว่า |
|-------------|---------|--------------|
| MPU6050_light | rfetick | `MPU6050_light` |
| ArduinoJson | Benoit Blanchon | `ArduinoJson` |

> **หมายเหตุ:** `WebServer`, `WiFi`, `Wire` มาพร้อมกับ ESP32 board package แล้ว ไม่ต้องติดตั้งเพิ่ม

---

## 5. ตั้งค่าโค้ดก่อนอัปโหลด

เปิดไฟล์ `siamsi_esp32.ino` แล้วแก้ค่าตรงส่วนนี้:

```cpp
// ============================================================
//  ตั้งค่า — แก้ตรงนี้ก่อนอัปโหลด
// ============================================================
const char* WIFI_SSID        = "YOUR_WIFI_SSID";     // ชื่อ WiFi ของคุณ
const char* WIFI_PASS        = "YOUR_WIFI_PASSWORD"; // รหัส WiFi ของคุณ
```

ค่าอื่นที่ปรับได้ตามต้องการ:

```cpp
const float SHAKE_THRESHOLD  = 80.0f;   // deg/s — ลดถ้า sensor ไวเกิน / เพิ่มถ้าไวน้อยเกิน
const int   SHAKE_DURATION_S = 5;      // วินาทีที่จับเวลาเขย่า (5 = 5 วินาที)
const int   COOLDOWN_S       = 3;       // วินาที cooldown หลังออกผล
```

---

## 6. อัปโหลดโค้ด

1. เสียบ ESP32 เข้าคอมพิวเตอร์ผ่าน USB
2. เลือก Board: **Tools → Board → esp32 → ESP32 Dev Module**
3. เลือก Port: **Tools → Port → COM_x** (Windows) หรือ `/dev/ttyUSB0` (Linux/Mac)
4. กด **Upload** (ลูกศรชี้ขวา)
5. เปิด **Serial Monitor** (Ctrl+Shift+M) ตั้ง Baud Rate เป็น **115200**

### ข้อความที่ควรเห็นใน Serial Monitor

```
=== กระบอกเซียมซี v2.0 ===
เชื่อมต่อ WiFi: MyWiFi..........
IP: 192.168.1.105
NTP sync ✓
MPU6050 พบแล้ว — Calibrate (วางนิ่ง 3 วิ)...
Calibrate ✓
Web server พร้อม ✓
[WAIT]
```

> ระหว่าง Calibrate **ต้องวาง ESP32+MPU6050 นิ่งๆ บนโต๊ะ** ห้ามถือหรือขยับ 3 วินาที

---

## 7. การใช้งาน

### 7.1 เปิดหน้าเว็บ

นำ IP ที่แสดงใน Serial Monitor ใส่ในเบราว์เซอร์ของมือถือหรือ PC  
(ต้องอยู่ใน WiFi เดียวกับ ESP32)

```
http://192.168.1.105
```

### 7.2 การเขย่า

1. ถือกระบอก/อุปกรณ์ที่ติด ESP32+MPU6050 ไว้
2. **เขย่าแรงๆ** จนหน้าเว็บแสดง "ตรวจพบการเขย่า!" และจุดสีเขียวติด
3. ระบบจะเริ่มจับเวลา 5 วินาที — แสดง progress bar
4. เขย่าต่อเนื่องตลอด 5 วินาที (หรือวางนิ่งก็ได้ ระบบบันทึกค่าทุก 100ms)
5. เมื่อครบเวลา ระบบแสดง **เลข 6 หลัก** บนหน้าเว็บ
6. พัก 3 วินาที (Cooldown) แล้วกลับสู่โหมดรอเขย่าใหม่

### 7.3 กรณีไม่มี WiFi (AP Mode)

หาก ESP32 เชื่อมต่อ WiFi ไม่ได้ จะเปิด Access Point อัตโนมัติ:

| ค่า | รายละเอียด |
|-----|-----------|
| SSID | `SiamsiAP` |
| Password | `siamsi1234` |
| IP | `192.168.4.1` |

เชื่อมต่อโทรศัพท์ไปที่ `SiamsiAP` แล้วเปิด `http://192.168.4.1`

---

## 8. State Machine

```
┌─────────────┐    เขย่า >= 5 ครั้ง     ┌─────────────┐
│  WAIT_SHAKE │ ─────────────────────▶ │  RECORDING  │
│  รอการเขย่า │                         │  5 วินาที   │
└─────────────┘                         └──────┬──────┘
       ▲                                       │ ครบเวลา
       │                                       ▼
       │                                ┌─────────────┐
       │                                │  COMPUTING  │
       │                                │  คำนวณเลข   │
       │                                └──────┬──────┘
       │                                       │ ทันที
       │                                       ▼
       │         ครบ 3 วินาที           ┌─────────────┐
       └───────────────────────────────│  COOLDOWN   │
                                        │  พักระบบ    │
                                        └─────────────┘
```

### รายละเอียดแต่ละ State

| State | การทำงาน | เงื่อนไขออก |
|-------|---------|-----------|
| WAIT_SHAKE | เก็บ 20 sample ล่าสุดใน circular buffer ตรวจว่ามีการเขย่า ≥ 5 ครั้ง | buffer มี shaking ≥ 5 ครั้ง |
| RECORDING | เก็บค่า sum, sum-of-squares ทุก 100ms สำหรับ avg และ RMS | ครบ 5 วินาที |
| COMPUTING | คำนวณ avg, RMS, ส่งเข้า FNV hash + hardware RNG | ทันที → COOLDOWN |
| COOLDOWN | แสดงผลเลข รอ 3 วินาที | ครบ 3 วินาที |

---

## 9. ตาราง API

### `GET /`
หน้าเว็บ HTML (ดูบนเบราว์เซอร์)

### `GET /api/status`
ข้อมูล JSON แบบ real-time

**ตัวอย่าง Response:**

```json
{
  "gx": "12.3",
  "gy": "-5.7",
  "shaking": false,
  "status": "รอการเขย่า",
  "lottery": "123456",
  "lottery_time": "21/04/2026 14:30:00",
  "recording": false,
  "progress": 0.0,
  "history": [
    { "number": "123456", "datetime": "21/04/2026 14:30:00" },
    { "number": "789012", "datetime": "21/04/2026 09:15:22" }
  ]
}
```

| Field | Type | คำอธิบาย |
|-------|------|---------|
| `gx` | string | ค่า Gyro แกน X (°/s) |
| `gy` | string | ค่า Gyro แกน Y (°/s) |
| `shaking` | bool | กำลังเขย่าอยู่หรือไม่ |
| `status` | string | ข้อความสถานะภาษาไทย |
| `lottery` | string | เลขหวย 6 หลักล่าสุด |
| `lottery_time` | string | วันเวลาที่ออกผล |
| `recording` | bool | อยู่ใน state RECORDING หรือไม่ |
| `progress` | float | ความคืบหน้าการบันทึก 0.0–1.0 |
| `history` | array | ผล 10 รายการล่าสุด (RAM เท่านั้น) |

---

## 10. การปรับแต่งค่า

### ปรับความไวในการตรวจเขย่า

```cpp
const float SHAKE_THRESHOLD  = 80.0f;   // เพิ่มถ้า trigger ง่ายเกิน / ลดถ้า trigger ยากเกิน
const int   SHAKE_BUF_MIN    = 10;      // sample ขั้นต่ำก่อนตัดสิน
const int   SHAKE_POSITIVE   = 5;       // ใน buffer ต้องมี shaking ≥ ค่านี้
```

### เปลี่ยนเวลาบันทึก

```cpp
const int   SHAKE_DURATION_S = 5;      // 5 = 5 วินาที, 60 = 1 นาที, 300 = 5 นาที
```

### เปลี่ยน Cooldown

```cpp
const int   COOLDOWN_S       = 3;       // วินาที
```

### เปลี่ยน Time Zone

```cpp
const long  GMT_OFFSET_SEC   = 7 * 3600;   // UTC+7 (ไทย)
// ญี่ปุ่น: 9 * 3600
// อังกฤษ: 0
```

---

## 11. การแก้ปัญหา

### MPU6050 ไม่พบ (status != 0)

```
MPU6050 ไม่พบ (status=1) ลองใหม่...
```

**ตรวจสอบ:**
- สาย SDA → GPIO 21, SCL → GPIO 22 ถูกต้องหรือไม่
- ต่อไฟ 3.3V ไม่ใช่ 5V
- ลอง `Wire.begin(21, 22)` แล้วรัน I2C Scanner sketch เพื่อหา address

**I2C Scanner sketch (ทดสอบ):**

```cpp
#include <Wire.h>
void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);
  for (byte a = 1; a < 127; a++) {
    Wire.beginTransmission(a);
    if (Wire.endTransmission() == 0)
      Serial.printf("พบ device ที่ address: 0x%02X\n", a);
  }
}
void loop(){}
```

ถ้าพบที่ `0x68` หรือ `0x69` แสดงว่า MPU6050 ใช้งานได้

---

### WiFi เชื่อมต่อไม่ได้

- ตรวจ SSID และรหัสผ่านใน code ว่าพิมพ์ถูก (case-sensitive)
- ESP32 รองรับ WiFi 2.4GHz เท่านั้น ไม่รองรับ 5GHz
- ถ้าเชื่อมไม่ได้ ระบบจะเปิด AP mode อัตโนมัติ (`SiamsiAP`)

---

### ค่า Gyro ติด -0.01 ไม่เปลี่ยน

Calibration offset ดูดค่าจริงทิ้ง ให้:

1. กด Reset บน ESP32
2. วาง sensor นิ่งๆ บนโต๊ะ อย่าถือ ระหว่าง "Calibrate (วางนิ่ง 3 วิ)"
3. ดู Serial Monitor ว่า Calibrate เสร็จก่อนจะจับถือ

---

### หน้าเว็บค้าง / โหลดช้า

เวอร์ชัน v2.0 ใช้ `millis()` แทน `delay()` แล้ว ถ้ายังค้างอยู่:

- ตรวจ WiFi signal strength — ถ้าสัญญาณอ่อน response จะช้า
- ลอง refresh หน้าเว็บ
- ตรวจว่าไม่มีอุปกรณ์อื่นใช้ port 80 เดียวกัน

---

### ประวัติหายหลังไฟดับ

ประวัติเก็บใน RAM เท่านั้น ถ้าต้องการให้คงอยู่ถาวร สามารถเพิ่ม **Preferences** library:

```cpp
#include <Preferences.h>
Preferences pref;
// pref.begin("siamsi", false);
// pref.putString("last", lastNumber);
```

---

## 12. สิ่งที่แก้ไขจาก v1.0

| ปัญหา v1.0 | การแก้ไขใน v2.0 |
|-----------|----------------|
| `delay(100)` ใน loop ทำให้ web ค้าง | ใช้ `millis()` + early return แทน |
| RMS คำนวณผิด (ส่ง `abs(avgX)` แทน RMS จริง) | เก็บ `recSumSqX` แยก แล้วคำนวณ `sqrtf(sumSq/n)` |
| `gyroBufferIdx` ไม่ reset ทำให้นับค่าเก่า | `shakeBufReset()` เรียกใน `enterWait()` ทุกครั้ง |
| `StaticJsonDocument<1024>` เล็กเกินสำหรับ history | เปลี่ยนเป็น `DynamicJsonDocument<2048>` |
| ไม่มี NTP → timestamp เป็นแค่ uptime | เพิ่ม `configTime()` + fallback uptime |
| Google Fonts → ใช้ไม่ได้โดยไม่มีอินเทอร์เน็ต | เปลี่ยนเป็น system font stack |
| ไม่มี CORS header | เพิ่ม `Access-Control-Allow-Origin: *` |
| entropy ต่ำ (ใช้แค่ timer) | เพิ่ม `esp_random()` (hardware RNG ของ ESP32) |
| AP password สั้นเกิน | เปลี่ยนจาก `siamsi123` เป็น `siamsi1234` (≥8 ตัว) |
| I2C speed default 100kHz | เพิ่ม `Wire.setClock(400000)` fast mode |
