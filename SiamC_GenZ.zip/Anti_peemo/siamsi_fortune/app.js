/* ============================================================
   กระบอกเซียมซี — app.js  (ESP32 + MPU6050 Fortune)
   ============================================================ */

// ─── State ───
let espIp = '';
let polling = null;
let demoMode = false;
let demoInterval = null;
let state = 'WAIT';          // WAIT → RECORDING → COMPUTING → COOLDOWN
let recordStart = 0;
const RECORD_MS = 5 * 1000;         // 5 seconds
const DEMO_RECORD_MS = 8000;
let gyroSamples = [];
let history = JSON.parse(localStorage.getItem('siamsi_history') || '[]');

// ─── DOM refs ───
const $ = id => document.getElementById(id);
const connectionDot   = $('connectionDot');
const connectionLabel = $('connectionLabel');
const shakeCard       = $('shakeCard');
const shakeIcon       = $('shakeIcon');
const shakeStatus     = $('shakeStatus');
const shakeSub        = $('shakeSub');
const barX = $('barX'), barY = $('barY');
const gyroX = $('gyroX'), gyroY = $('gyroY');
const progressPct  = $('progressPct');
const progressFill = $('progressFill');
const progressTime = $('progressTime');
const stateBadge   = $('stateBadge');
const fortuneSection   = $('fortuneSection');
const overallLevel     = $('overallLevel');
const overallStars     = $('overallStars');
const overallMsg       = $('overallMsg');
const scoreFill        = $('scoreFill');
const scoreLabel       = $('scoreLabel');
const lotteryTime      = $('lotteryTime');
const categoryGrid     = $('categoryGrid');
const fortuneScrollText = $('fortuneScrollText');
const historyList      = $('historyList');
const confettiEl       = $('confetti');

// ─── Stars background ───
(function initStars() {
  const bg = $('starsBg');
  for (let i = 0; i < 120; i++) {
    const s = document.createElement('div');
    s.className = 'star';
    const size = Math.random() * 2.5 + 1;
    Object.assign(s.style, {
      width: size + 'px', height: size + 'px',
      left: Math.random() * 100 + '%', top: Math.random() * 100 + '%',
      animationDuration: (Math.random() * 4 + 2) + 's',
      animationDelay: (Math.random() * 5) + 's'
    });
    bg.appendChild(s);
  }
})();

// ─── Render history on load ───
renderHistory();

// ─── Connect to ESP32 ───
function connectToESP() {
  const ip = $('espIp').value.trim();
  if (!ip) { alert('กรุณากรอก IP ของ ESP32'); return; }
  if (demoMode) toggleDemo();
  espIp = ip;
  setConnection('connecting', 'กำลังเชื่อมต่อ…');
  if (polling) clearInterval(polling);
  fetchStatus().then(ok => {
    if (ok) {
      setConnection('connected', 'เชื่อมต่อแล้ว');
      polling = setInterval(fetchStatus, 900);
    } else {
      setConnection('error', 'เชื่อมต่อไม่ได้');
    }
  });
}

async function fetchStatus() {
  try {
    const r = await fetch(`http://${espIp}/api/status`, { signal: AbortSignal.timeout(3000) });
    const d = await r.json();
    handleData(d);
    return true;
  } catch { setConnection('error', 'ขาดการเชื่อมต่อ'); return false; }
}

function setConnection(type, label) {
  connectionDot.className = 'dot' + (type === 'connected' ? ' connected' : type === 'error' ? ' error' : type === 'demo' ? ' demo' : type === 'shaking' ? ' shaking' : '');
  connectionLabel.textContent = label;
}

// ─── Demo Mode ───
function toggleDemo() {
  demoMode = !demoMode;
  const btn = $('btnDemo');
  if (demoMode) {
    if (polling) { clearInterval(polling); polling = null; }
    btn.textContent = '⏹ หยุด Demo';
    btn.classList.add('active');
    setConnection('demo', 'Demo Mode');
    state = 'WAIT'; updateStateMachine();
    demoInterval = setInterval(demoTick, 300);
  } else {
    btn.textContent = '▶ ทดลอง Demo Mode';
    btn.classList.remove('active');
    clearInterval(demoInterval); demoInterval = null;
    setConnection('', 'ยังไม่ได้เชื่อมต่อ');
    resetUI();
  }
}

let demoShaking = false;
let demoShakeTimer = 0;
function demoTick() {
  // Random shake bursts
  if (state === 'WAIT' && Math.random() < 0.06 && !demoShaking) {
    demoShaking = true; demoShakeTimer = 6 + Math.floor(Math.random() * 8);
  }
  const gx = demoShaking ? (Math.random() - 0.5) * 300 : (Math.random() - 0.5) * 30;
  const gy = demoShaking ? (Math.random() - 0.5) * 300 : (Math.random() - 0.5) * 30;
  const isShake = Math.abs(gx) > 80 || Math.abs(gy) > 80;
  if (demoShaking) { demoShakeTimer--; if (demoShakeTimer <= 0) demoShaking = false; }
  handleData({ gyroX: gx, gyroY: gy, shaking: isShake, state: state });
}

// ─── Handle incoming data ───
function handleData(d) {
  updateGyro(d.gyroX || 0, d.gyroY || 0);
  const isShaking = d.shaking || false;
  updateShakeUI(isShaking);

  if (state === 'WAIT' && isShaking) {
    startRecording();
  } else if (state === 'RECORDING') {
    gyroSamples.push({ x: d.gyroX || 0, y: d.gyroY || 0, t: Date.now() });
    const recMs = demoMode ? DEMO_RECORD_MS : RECORD_MS;
    const elapsed = Date.now() - recordStart;
    const pct = Math.min(100, (elapsed / recMs) * 100);
    updateProgress(pct, elapsed, recMs);
    if (elapsed >= recMs) startComputing();
  }
}

// ─── Gyro bars ───
function updateGyro(x, y) {
  const maxVal = 250;
  const pctX = Math.min(Math.abs(x) / maxVal * 100, 100);
  const pctY = Math.min(Math.abs(y) / maxVal * 100, 100);
  barX.style.width = pctX + '%';
  barY.style.width = pctY + '%';
  gyroX.textContent = x.toFixed(1) + ' °/s';
  gyroY.textContent = y.toFixed(1) + ' °/s';
  const highX = Math.abs(x) > 80, highY = Math.abs(y) > 80;
  barX.classList.toggle('high', highX);
  barY.classList.toggle('high', highY);
  gyroX.classList.toggle('high', highX);
  gyroY.classList.toggle('high', highY);
}

// ─── Shake visual ───
function updateShakeUI(shaking) {
  shakeCard.classList.toggle('shaking', shaking);
  if (shaking && state === 'WAIT') {
    shakeStatus.textContent = '🔥 กำลังเขย่า!';
    shakeSub.textContent = 'เขย่าต่อไปอีกนิด…';
    if (!demoMode) setConnection('shaking', 'กำลังเขย่า!');
  } else if (state === 'WAIT') {
    shakeStatus.textContent = 'รอการเขย่า';
    shakeSub.textContent = 'ถือกระบอกแล้วเขย่าแรงๆ';
  }
}

// ─── State Machine ───
function setState(s) {
  state = s;
  updateStateMachine();
}
function updateStateMachine() {
  ['stateWait','stateRec','stateComp','stateCool'].forEach(id => $(id).classList.remove('active'));
  const map = { WAIT:'stateWait', RECORDING:'stateRec', COMPUTING:'stateComp', COOLDOWN:'stateCool' };
  if (map[state]) $(map[state]).classList.add('active');
  stateBadge.textContent = state;
  stateBadge.className = 'state-badge' + ({RECORDING:' recording',COMPUTING:' computing',COOLDOWN:' cooldown'}[state] || '');
}

function startRecording() {
  setState('RECORDING');
  gyroSamples = [];
  recordStart = Date.now();
  shakeStatus.textContent = '⏺️ กำลังบันทึก…';
  shakeSub.textContent = 'เขย่าเรื่อยๆ เพื่อสะสมพลังดวง';
  shakeIcon.textContent = '🔮';
}

function startComputing() {
  setState('COMPUTING');
  shakeStatus.textContent = '🧮 กำลังคำนวณดวง…';
  shakeSub.textContent = 'รอสักครู่…';
  shakeIcon.textContent = '✨';
  updateProgress(100, 0, 0);
  setTimeout(() => generateFortune(), 1800);
}

function startCooldown() {
  setState('COOLDOWN');
  shakeStatus.textContent = '❄️ พักก่อน';
  shakeSub.textContent = 'รอ 5 วินาทีแล้วเขย่าใหม่ได้';
  shakeIcon.textContent = '🫙';
  setTimeout(() => {
    setState('WAIT');
    shakeStatus.textContent = 'รอการเขย่า';
    shakeSub.textContent = 'ถือกระบอกแล้วเขย่าแรงๆ';
    updateProgress(0, 0, demoMode ? DEMO_RECORD_MS : RECORD_MS);
  }, 5000);
}

function updateProgress(pct, elapsed, total) {
  progressPct.textContent = Math.round(pct) + '%';
  progressFill.style.width = pct + '%';
  progressFill.classList.toggle('complete', pct >= 100);
  if (total > 0) {
    const eS = (elapsed/1000).toFixed(1);
    const tS = (total/1000).toFixed(1);
    progressTime.textContent = `${eS} / ${tS} วินาที`;
  }
}

// ─── Fortune Generation ───
const CATEGORIES = [
  { key:'money',  icon:'💰', name:'การเงิน',     cls:'cat-money' },
  { key:'love',   icon:'💗', name:'ความรัก',     cls:'cat-love' },
  { key:'career', icon:'💼', name:'การงาน',      cls:'cat-career' },
  { key:'health', icon:'🍀', name:'สุขภาพ',      cls:'cat-health' },
  { key:'social', icon:'🤝', name:'สังคม',       cls:'cat-social' },
  { key:'spirit', icon:'🙏', name:'จิตวิญญาณ',  cls:'cat-spirit' }
];

const FORTUNE_MSGS = {
  money: [
    'ระวังรายจ่ายที่ไม่จำเป็น อดทนไว้จะดีขึ้น',
    'การเงินพอไปได้ แต่ควรวางแผนมากขึ้น',
    'มีรายได้เสริมเข้ามา จัดสรรให้ดี',
    'โชคลาภกำลังมา! เก็บออมไว้ให้มาก',
    'ดวงการเงินรุ่งเรืองมาก มีโอกาสรับทรัพย์ก้อนใหญ่',
    'เงินทองไหลมาเทมา! ดวงเศรษฐีเปิดแล้ว'
  ],
  love: [
    'ความรักอาจมีอุปสรรค ใจเย็นไว้',
    'คนรักอาจมีเรื่องให้ขัดใจ แต่ผ่านไปได้',
    'ความสัมพันธ์มั่นคงดี มีความสุข',
    'มีเกณฑ์ได้พบคนพิเศษ เปิดใจรับสิ่งใหม่',
    'ความรักหวานชื่นมาก คนรักจะมีเซอร์ไพรส์ให้',
    'ดวงความรักสุดปัง! ชีวิตคู่จะเปลี่ยนไปในทางที่ดี'
  ],
  career: [
    'การงานอาจสะดุด ต้องอดทนมากขึ้น',
    'งานเยอะแต่ก็ผ่านไปได้ ถ้าตั้งใจทำ',
    'มีโอกาสก้าวหน้า ทำให้ดีที่สุด',
    'เจ้านายจะเห็นฝีมือ โอกาสเลื่อนขั้นใกล้เข้ามา',
    'ดวงการงานดีมาก โปรเจกต์สำเร็จลุล่วง',
    'ดวงการงานเปิดทุกประตู ความสำเร็จอยู่แค่เอื้อม!'
  ],
  health: [
    'ระวังสุขภาพให้มาก พักผ่อนให้เพียงพอ',
    'สุขภาพพอใช้ได้ แต่ควรออกกำลังกายบ้าง',
    'สุขภาพแข็งแรงดี ทำต่อไป',
    'ร่างกายฟิตมาก พลังงานเต็มเปี่ยม',
    'สุขภาพดีเยี่ยม มีพลังล้นเหลือ',
    'ดวงสุขภาพเป็นเลิศ! แข็งแรงทั้งกายและใจ'
  ],
  social: [
    'ระวังเรื่องคนรอบข้าง อย่าไว้ใจง่าย',
    'สังคมราบรื่นพอสมควร มีมิตรดีช่วยเหลือ',
    'มิตรภาพแน่นแฟ้น มีคนคอยซัพพอร์ต',
    'คนรอบข้างรักใคร่ เป็นที่ชื่นชมของสังคม',
    'ดวงสังคมดีเด่น มีเครือข่ายที่เข้มแข็ง',
    'เป็นดาวเด่นของสังคม! ทุกคนอยากเข้าหา'
  ],
  spirit: [
    'จิตใจว้าวุ่น ลองนั่งสมาธิทำใจให้สงบ',
    'สภาพจิตใจปกติดี แต่ควรหาเวลาพักผ่อน',
    'จิตใจสงบมั่นคง มีสติในการใช้ชีวิต',
    'ปัญญาเฉียบแหลม เข้าใจสิ่งต่างๆ ได้ลึกซึ้ง',
    'จิตใจผ่องใส บุญเก่าส่งผลดี',
    'ดวงจิตวิญญาณสว่างไสว! บารมีเปิดเต็มที่'
  ]
};

const OVERALL_MSGS = [
  'ดวงชะตายังไม่เปิด ต้องทำบุญเสริมดวงมากขึ้น ความพยายามจะเป็นกุญแจสำคัญที่พาคุณผ่านช่วงเวลานี้ไปได้',
  'ดวงชะตาพอไปได้ มีทั้งขึ้นทั้งลง แต่ถ้าตั้งใจดีทำดี ทุกอย่างจะค่อยๆ ดีขึ้นเอง อย่าท้อแท้',
  'ดวงชะตากำลังเปลี่ยนแปลงไปในทิศทางที่ดี สิ่งดีๆ กำลังจะเข้ามาในชีวิต จงเตรียมพร้อมรับโชค',
  'ดวงชะตาดีมาก มีเทวดาคุ้มครอง ทำอะไรก็ราบรื่น โชคลาภวิ่งเข้าหา สมหวังทุกประการ',
  'ดวงชะตาเปิดเต็มที่! นี่คือช่วงเวลาทองของคุณ ความสำเร็จ ความรัก และโชคลาภจะหลั่งไหลเข้ามา ฟ้าเปิดทุกทิศ!',
  'มหาโชค! ดวงสว่างจ้าเหมือนพระอาทิตย์ ชีวิตจะพลิกผันไปในทางที่ดีอย่างไม่น่าเชื่อ ทุกสิ่งที่ปรารถนาจะเป็นจริง!'
];

const LUCK_LEVELS = [
  { min:0,  label:'ดวงตก',           cls:'level-poor',    stars:1 },
  { min:20, label:'ดวงน้อย',          cls:'level-low',     stars:2 },
  { min:40, label:'ดวงปานกลาง',       cls:'level-medium',  stars:3 },
  { min:60, label:'ดวงดี',            cls:'level-good',    stars:4 },
  { min:78, label:'ดวงดีมาก!',        cls:'level-great',   stars:5 },
  { min:92, label:'🎆 แจ็คพอต! 🎆',  cls:'level-jackpot', stars:5 }
];

function seedFromSamples() {
  if (gyroSamples.length === 0) return Math.random() * 999999;
  let seed = 0;
  gyroSamples.forEach((s, i) => {
    seed += (Math.abs(s.x) * 17 + Math.abs(s.y) * 31 + (s.t % 10000)) * (i + 1);
  });
  return seed;
}

function seededRandom(seed) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; };
}

function generateFortune() {
  const seed = seedFromSamples();
  const rng = seededRandom(seed);

  // 6-digit number
  const digits = [];
  for (let i = 0; i < 6; i++) digits.push(Math.floor(rng() * 10));
  const numberStr = digits.join('');

  // Category scores
  const catScores = {};
  CATEGORIES.forEach(c => { catScores[c.key] = Math.floor(rng() * 85 + 15); });

  // Boost: if lots of high-energy samples, boost scores
  const avgEnergy = gyroSamples.length > 0
    ? gyroSamples.reduce((s, v) => s + Math.abs(v.x) + Math.abs(v.y), 0) / gyroSamples.length
    : 50;
  const boost = Math.min(15, avgEnergy / 20);
  CATEGORIES.forEach(c => { catScores[c.key] = Math.min(100, catScores[c.key] + Math.floor(rng() * boost)); });

  // Overall
  const vals = Object.values(catScores);
  const overall = Math.round(vals.reduce((a, b) => a + b, 0) / vals.length);
  const level = [...LUCK_LEVELS].reverse().find(l => overall >= l.min) || LUCK_LEVELS[0];

  // Render digits with reveal animation
  digits.forEach((d, i) => {
    const el = $('ld' + i);
    el.textContent = d;
    el.classList.remove('reveal');
    void el.offsetWidth; // reflow
    el.style.animationDelay = (i * 0.12) + 's';
    el.classList.add('reveal');
  });

  // Overall banner
  overallLevel.textContent = level.label;
  overallLevel.className = 'overall-level ' + level.cls;
  overallStars.textContent = '⭐'.repeat(level.stars) + '☆'.repeat(5 - level.stars);
  const msgIdx = Math.min(OVERALL_MSGS.length - 1, Math.floor(overall / 18));
  overallMsg.textContent = OVERALL_MSGS[msgIdx];
  setTimeout(() => {
    scoreFill.style.width = overall + '%';
    scoreLabel.textContent = overall + ' / 100';
  }, 200);
  lotteryTime.textContent = new Date().toLocaleString('th-TH');

  // Category cards
  categoryGrid.innerHTML = '';
  CATEGORIES.forEach((c, i) => {
    const score = catScores[c.key];
    const msgList = FORTUNE_MSGS[c.key];
    const msgI = Math.min(msgList.length - 1, Math.floor(score / 18));
    const catLevel = [...LUCK_LEVELS].reverse().find(l => score >= l.min) || LUCK_LEVELS[0];
    const card = document.createElement('div');
    card.className = 'cat-card ' + c.cls;
    card.style.animationDelay = (i * 0.1) + 's';
    card.innerHTML = `
      <div class="cat-header">
        <span class="cat-icon">${c.icon}</span>
        <span class="cat-name">${c.name}</span>
        <span class="cat-stars">${'⭐'.repeat(catLevel.stars)}${'☆'.repeat(5-catLevel.stars)}</span>
      </div>
      <div class="cat-bar-wrap"><div class="cat-bar" style="width:0%"></div></div>
      <div class="cat-score">${score} / 100</div>
      <div class="cat-msg">${msgList[msgI]}</div>`;
    categoryGrid.appendChild(card);
    setTimeout(() => card.querySelector('.cat-bar').style.width = score + '%', 300 + i * 100);
  });

  // Grand fortune text
  const grandParts = CATEGORIES.map(c => {
    const msgList = FORTUNE_MSGS[c.key];
    const msgI = Math.min(msgList.length - 1, Math.floor(catScores[c.key] / 18));
    return `${c.icon} ${c.name}: ${msgList[msgI]}`;
  });
  fortuneScrollText.textContent = `เลขชะตา: ${numberStr}\nระดับโชค: ${level.label} (${overall}/100)\n\n${grandParts.join('\n')}\n\n${OVERALL_MSGS[msgIdx]}`;

  // Show fortune section
  fortuneSection.style.display = '';

  // Confetti for high scores
  if (overall >= 60) spawnConfetti(overall >= 90 ? 80 : 40);

  // Save history
  addHistory(numberStr, overall, level.label);

  // Move to cooldown
  startCooldown();
}

// ─── Confetti ───
function spawnConfetti(count) {
  confettiEl.innerHTML = '';
  const colors = ['#f5c842','#ff9f1c','#7b2fff','#4cc9f0','#ff6b9d','#2dc653','#b088ff','#e63946'];
  for (let i = 0; i < count; i++) {
    const p = document.createElement('div');
    p.className = 'confetti-piece';
    const c = colors[Math.floor(Math.random() * colors.length)];
    const w = Math.random() * 8 + 4;
    const h = Math.random() * 12 + 6;
    Object.assign(p.style, {
      left: Math.random() * 100 + '%',
      width: w + 'px', height: h + 'px',
      background: c,
      animationDuration: (Math.random() * 2 + 2) + 's',
      animationDelay: (Math.random() * 1.5) + 's'
    });
    confettiEl.appendChild(p);
  }
  setTimeout(() => confettiEl.innerHTML = '', 5000);
}

// ─── History ───
function addHistory(number, score, level) {
  history.unshift({ number, score, level, time: new Date().toISOString() });
  if (history.length > 20) history.pop();
  localStorage.setItem('siamsi_history', JSON.stringify(history));
  renderHistory();
}

function renderHistory() {
  if (history.length === 0) {
    historyList.innerHTML = '<div class="history-empty">ยังไม่มีประวัติ</div>';
    return;
  }
  historyList.innerHTML = history.map((h, i) => {
    const d = new Date(h.time);
    const dt = d.toLocaleString('th-TH', { dateStyle:'short', timeStyle:'short' });
    return `<div class="history-item">
      <span class="history-rank">${i + 1}</span>
      <span class="history-number">${h.number.slice(0,3)}·${h.number.slice(3)}</span>
      <div class="history-meta">
        <span class="history-datetime">${dt}</span>
        <span class="history-luck">${h.level} (${h.score})</span>
      </div>
    </div>`;
  }).join('');
}

// ─── Reset ───
function resetUI() {
  state = 'WAIT';
  updateStateMachine();
  updateGyro(0, 0);
  updateShakeUI(false);
  updateProgress(0, 0, RECORD_MS);
  shakeIcon.textContent = '🫙';
  shakeStatus.textContent = 'รอการเขย่า';
  shakeSub.textContent = 'ถือกระบอกแล้วเขย่าแรงๆ';
}

// ─── Init state machine ───
updateStateMachine();
updateProgress(0, 0, RECORD_MS);
